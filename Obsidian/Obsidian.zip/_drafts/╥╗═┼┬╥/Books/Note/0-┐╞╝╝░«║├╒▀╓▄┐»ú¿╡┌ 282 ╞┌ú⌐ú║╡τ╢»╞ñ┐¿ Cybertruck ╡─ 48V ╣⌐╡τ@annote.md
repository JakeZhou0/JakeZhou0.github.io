---
title: "srAnnote@科技爱好者周刊（第 282 期）：电动皮卡 Cybertruck 的 48V 供电"
alias: ["srAnnote@今日新闻
","srAnnote@科技爱好者周刊（第 282 期）：电动皮卡 Cybertruck 的 48V 供电"]
type: Simpread
tag: #阮一峰
---

## 科技爱好者周刊（第 282 期）：电动皮卡 Cybertruck 的 48V 供电

> [!md] Metadata  
> **标题**:: " 科技爱好者周刊（第 282 期）：电动皮卡 Cybertruck 的 48V 供电 "  
> **日期**:: [[2023-12-15]]  

### Annotations

> [📌](<http://localhost:7026/reading/0#id=1702618697396>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 48V 供电
> - 48v 代表着什么？

^sran-1702618697396

> [📌](<http://localhost:7026/reading/0#id=1702618863217>) <mark style="background-color: #ffeb3b">Highlight</mark>
> 用电量太大了，12V 电压会使得电线不堪负荷
> - 12V 和 48V 的区别就是这个吗？

^sran-1702618863217

> [📌](<http://localhost:7026/reading/0#id=1702618921833>) <mark style="background-color: #ffeb3b">Highlight</mark>
> 电压提高了 4 倍，电流只需要原来的四分之一
> - 提升电压的好处

^sran-1702618921833

> [📌](<http://localhost:7026/reading/0#id=1702619067232>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> 人工智能线下沙龙（深圳站）
> - 很可惜，对于我来说离得太远了

^sran-1702619067232

> [📌](<http://localhost:7026/reading/0#id=1702619140662>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> 盲人美术馆
> - 艺术中比较重要的成分是色彩，而盲人对于色彩的缺失，可以依靠触觉拟补吗

^sran-1702619140662

> [📌](<http://localhost:7026/reading/0#id=1702619392127>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> 考虑到船只总是选择风平浪静的路线，这个设计就算能做出来，发电量可能非常少
> - 专门做一个去恶劣天气的发电装置

^sran-1702619392127

> [📌](<http://localhost:7026/reading/0#id=1702619453299>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 首个基因编辑疗法
> - 这个有什么作用？可以给我们普通人带来什么？

^sran-1702619453299

> [📌](<http://localhost:7026/reading/0#id=1702619518905>) <mark style="background-color: #a2e9f2">Highlight</mark>
> 最低价格是 220 万美元（约 1500 多万人民币），根本不是普通人可以负担的

^sran-1702619518905

> [📌](<http://localhost:7026/reading/0#id=1702619544676>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> 2023 年 CSS 发展总结
> - 这个对于我学前端的来说，很重要。我需要时刻关注这些新技术。好的放入待阅读

^sran-1702619544676

> [📌](<http://localhost:7026/reading/0#id=1702619684571>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 他已经跳槽到 Booking.com
> - 为什么他要跳槽？

^sran-1702619684571

> [📌](<http://localhost:7026/reading/0#id=1702619722425>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> **所有网址** 保存一个备份
> - 对于我来说有什么作用？做视频？还是写个文章？

^sran-1702619722425

> [📌](<http://localhost:7026/reading/0#id=1702619776797>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 如何使用 Fail2ban 保护 SSH
> - Fali2ban 是什么？

^sran-1702619776797

> [📌](<http://localhost:7026/reading/0#id=1702619838735>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> Web 组件比 JavaScript 框架更长久
> - 什么是 Web 组件，如何实际应用？

^sran-1702619838735

> [📌](<http://localhost:7026/reading/0#id=1702619902558>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question #归档/📦/想法
> 如何将 MP3 文件转为 Opus 格式？
> - Opus 格式如何使用？现在主流的对于我来说还是 mp3

^sran-1702619902558

> [📌](<http://localhost:7026/reading/0#id=1702619961137>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 如何使用 GPT-3 解析非结构化数据
> - 什么是非结构化数据？将文章转化成非结构化数据的作用是什么？

^sran-1702619961137

> [📌](<http://localhost:7026/reading/0#id=1702620071950>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> GPT-3 将公司的招聘帖子转成 JSON 数据
> - 为什么需要转化 JSON？

^sran-1702620071950

> [📌](<http://localhost:7026/reading/0#id=1702620107091>) <mark style="background-color: #ffeb3b">Highlight</mark>
> Imagine
> - 可以记录一下，需要时再找一找

^sran-1702620107091

> [📌](<http://localhost:7026/reading/0#id=1702620177502>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> NotebookLM
> - 这个对于我来说可以去了解一下，不过现在需要一定的门槛使用。

^sran-1702620177502

> [📌](<http://localhost:7026/reading/0#id=1702620233936>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> Swagger/OpenAPI
> - Swagger/OpenAPI 是什么？

^sran-1702620233936

> [📌](<http://localhost:7026/reading/0#id=1702620277947>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> [RoomGPT](https://github.com/Nutlope/roomGPT)
> - 或许以后装修房子用的到哈哈

^sran-1702620277947

> [📌](<http://localhost:7026/reading/0#id=1702620351675>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> CodeGeeX2
> - 是否好用？与之前的相比如何？

^sran-1702620351675

> [📌](<http://localhost:7026/reading/0#id=1702620412676>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/想法
> 最漂亮的网页游戏
> - 这些网页游戏是可以去学习他们的美术风格的

^sran-1702620412676

> [📌](<http://localhost:7026/reading/0#id=1702620593015>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 创业公司几乎就是一个 " 生活在未来 " 的地方。在创业的早期，你就像活在未来，因为你只关注一件事，就是如何做出一个未来大受欢迎的新产品。
> - 这是创业每一个创业公司都要思考的问题吗

^sran-1702620593015

> [📌](<http://localhost:7026/reading/0#id=1702620661586>) <mark style="background-color: #ffeb3b">Highlight</mark> #归档/📦/question
> 具有讽刺意味的是，忠诚的员工更可能被选为企业的剥削目标。企业会假设，忠诚的员工更愿意为企业做出个人牺牲。
> - 这个思想是否说明，忠诚老实的人活该被欺负？奇怪

^sran-1702620661586
