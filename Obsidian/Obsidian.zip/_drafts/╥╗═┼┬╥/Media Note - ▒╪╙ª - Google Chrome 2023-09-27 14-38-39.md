---
media: https://www.bilibili.com/video/BV1wD421E7wL?t=5.5
---

- ![[../附件/【STN快报第七季48】这次蒂法用人格征服了我PT16.027S.webp|【STN快报第七季48】这次蒂法用人格征服了我 - 00:00:16|50]] [00:00:16](https://www.bilibili.com/video/BV1wD421E7wL#t=16.03) 有趣的笔记方式测试。
- ![[../附件/【STN快报第七季48】这次蒂法用人格征服了我PT35.721S.webp|【STN快报第七季48】这次蒂法用人格征服了我 - 00:00:35|50]] [00:00:35](https://www.bilibili.com/video/BV1wD421E7wL#t=35.72) 这是什么情况？
