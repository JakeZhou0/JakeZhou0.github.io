思路:

## 参考

- [Obsidian 笔记自动转换为 Jekyll 博客 | 简 悦 (jianyue.tech)](https://jianyue.tech/posts/obsidian-to-jekyll/#%E5%B0%86-obsidian-%E7%AC%94%E8%AE%B0%E8%BD%AC%E6%8D%A2%E4%B8%BA-jekyll-%E5%8D%9A%E6%96%87)
