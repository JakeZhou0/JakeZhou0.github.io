技巧：[[一团乱/Obsidian使用方法/编辑模式]] 和 [[一团乱/Obsidian使用方法/预览模式]] （快捷建 Ctrl + E ）
