## Introduction

- People like it when the **sun** is **shining**, and the sky is **blue**.  
![[../附件/Pasted image 20231218195103.png]]

## How to Talk about Sunny Weather?

- What a beautiful day!
- The sun is out. We should go outside and do something.
- What a lovely day!
- It's gorgeous outside today, isn't it?
- etc.

## Other Words in Connection with Sunny Weather

|   |   |   |
|---|---|---|
|sunburn/sunburnt|sunglasses/shades|suntan/suntanned|
|sunscreen/suntan lotion|sun hat|

## Questions about Sunny Weather

- What about where you live?
- Are there many days when it is sunny and bright?
- Do you like sunny weather?
- What kind of things do you do when it is sunny?
