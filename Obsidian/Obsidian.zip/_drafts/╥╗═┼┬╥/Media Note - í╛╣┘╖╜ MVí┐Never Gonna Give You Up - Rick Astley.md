---
media: https://www.bilibili.com/video/BV1GJ411x7h7
---
 
- ![[../附件/【官方 MV】Never Gonna Give You Up - Rick AstleyPT1M16.641S.webp|【官方 MV】Never Gonna Give You Up - Rick Astley - 00:01:16|50]] [00:01:16](https://www.bilibili.com/video/BV1GJ411x7h7#t=01:16.64) 这个是一个视频笔记。很棒的插件我爱死了。
