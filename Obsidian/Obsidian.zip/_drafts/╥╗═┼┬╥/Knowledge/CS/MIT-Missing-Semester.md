## CUES

### [[Knowledge/CS/Course overview + the shell]]

[[Knowledge/CS/Course overview + the shell#What shell is used for?]]

[[Knowledge/CS/Course overview + the shell#What will course teach us?]]

[[Knowledge/CS/Course overview + the shell#不理解的知识]]

[[Knowledge/CS/Course overview + the shell#在程序间创建连接]]

### [[Knowledge/CS/Java笔记/Shell Tools and Scripting]]

### [[Editors (Vim)]]

### [[Data Wrangling]]

### [[Command-line Environment]]

### [[Version Control (Git)]]

### [[Debugging and Profiling]]

### [[Metaprogramming]]

### [[Security and Cryptography]]

### [[Potpourri]]

### [[Q&A]]

## SUMMARY
