Enabled ships to calculate their latitude at sea.
