- [x] [[翻墙]]
- [x] [[Vim]]
- [x] [[Git]]
- [x] [[GitHub]]
- [ ] [[GNU Make]]
- [ ] [[CMake]]
- [ ] [[LaTeX]]
- [ ] [[Docker]]
- [ ] [[Scoop]]

## Course

- [ ] [[MIT-Missing-Semester]]
