## 1. [[Introduction to Derivatives]]

## 2. Examples of Derivatives

## 3. Derivative as Rate of Change

## 4. Limits and Continuity

## 5. Discontinuity

## 6. Calculating Derivatives

## 7. Derivatives of Sine and Cosine

## 8. Limits of Sine and Cosine

## 9. Product Rule

## 10. Quotient Rule

## 11.Chain Rule

## 12. Higher Derivatives

## SUMMARY
