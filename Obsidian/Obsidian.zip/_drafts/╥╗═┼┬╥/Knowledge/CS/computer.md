The earliest documented use of word is from 1613, in a book by [[Richard Braithwait]]. It was a job title.

This job title persisted until the late 1800s, when the meaning of computer started shifting to refer to devices.
