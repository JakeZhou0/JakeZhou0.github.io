## What is Binary?

Two states of electricity. We call this representation '[[Binary]]', the binary can represent important information.
