## 作用

排版系统

例如:

$$
\begin{align}
Hello, world!
\end{align}
$$

[安装LaTex与配置环境](安装LaTex与配置环境.md)
