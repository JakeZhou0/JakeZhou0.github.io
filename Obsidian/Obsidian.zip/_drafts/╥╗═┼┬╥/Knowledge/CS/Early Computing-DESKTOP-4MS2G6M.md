Computer are the lifeblood of today's world.

## 人类需要计算做什么?

Many objects need run by computing. Like builbing, and census, and battlefield etc.

**Computing can change every aspect of our lives**

## 人类离开计算还能发展吗?

I don't konw. Look the video.

## 计算机是如何组成的?

**They're just simple machine that perform complex actions through many layers of [[abstraction]].**

## Computing' Origins

The earliest recognized device for computing was the **[[abacus]]** invented around 2500BCE

Over the next 4000 years, humans developed [[astrolabe]]

, and [[slide rule]]……

Early computer poioneer [[Charles Babbage]] said: "**At each increase of knowledge, as well as on the contrivance of every new tool, human labour becomes abridged."**

The earliest documented use of the word "[[computer]]" is from 1613, in a book by [[Richard Braithwait]].

The [[Step Reckoner]], built by German polymath [[Gottfried Leibniz]] in 1694.

The [[Range Tables]] is used on the battlefield, which by the 1800s.

The [[Difference Engine]], and the [[Analytical Engine]].

[[Hollerith's machine]] is used on the census that demanded.

## SUMMARY

**Computing can change every aspect of our lives.**

**"At each increase of knowledge, as well as on the contrivance of every new tool, human labour becomes abridged."**
