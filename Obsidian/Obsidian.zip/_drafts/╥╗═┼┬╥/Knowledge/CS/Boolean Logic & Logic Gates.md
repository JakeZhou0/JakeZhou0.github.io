## Bolean Logic

### What is Bolean Logic?

**[[Knowledge/CS/Binary]]** add 'true' and 'false'.

On state: When electricity is flowing, represents "true" or "1"

off state: When no electricity flowing, represents "false" or "0"

### Why Need Binary?

The minimize these issues.

Aonther reason mathematics already existed that dealt exclusively with true and false values. **It's called [[Boolean Algebra]].**

### **Three Fundamental operations:**

NOT

![[Knowledge/CS/附件/Pasted image 20221214181804.png]]

This is NOT gates.

AND

![[Knowledge/CS/附件/Pasted image 20221214185830.png]]

OR

![[Knowledge/CS/附件/Pasted image 20221214191723.png]]

We call them GATES because they're controlling the path of our current.

### **WHY THREE FUNDAMENTAL OPERATIONS JUST SINGLE OUTPUT**

### What is Boolean Logic Used For?

## SUMMARY

What is Boolean Logic used for?
