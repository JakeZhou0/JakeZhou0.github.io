FINDING THE TANGENT LINE TO SOME GRAPH OF SOME FUNCTION AT SOME POINT$$y = f(x)$$$a + P = (x_0, y_0):$

## Your Solution

![[Pasted image 20221213151441.png]]

![[Pasted image 20221213151512.png]]

We visualize it.

OR:

	 Used high school math.

	 The equation for that line$y - y_0 = m (x - x_0)$

	 1.point $y_0 = f(x_0)$

	 2.slope $m = f'(x_0)$

### DISCUSS

DEF'N:

	$f'(x_0)$ the derivative,of f at $x_0$ is the slope of the thangent line to $y = f(x) at P.

## WHY WE NEED TO FIGURE OUT?

## HOW DID I DO THAT?

## HOW TO DO IT ANALYTICALLY, TO DO IT IN A WAY?
