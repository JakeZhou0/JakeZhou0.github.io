## [[MIT-Missing-Semester]]

## [[Harvard CS50: This is CS50x]]

## [[UCB CS61A: Structure and Interpretation of Computer Programs]]

## [[Duke University: Introductory C Programming Specialization]]

## [[Stanford CS106B/X]]

## [[Stanford CS106L: Standard C++ Programming]]

## [[Stanford CS110L: Safety in Systems Programming]]

## [[AmirKabir University of Technology AP1400-2: Advanced Programming]]
