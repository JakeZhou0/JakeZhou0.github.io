Completed in 1944 by [[IBM]] for the [[Allies]] during [[World War 2]].
