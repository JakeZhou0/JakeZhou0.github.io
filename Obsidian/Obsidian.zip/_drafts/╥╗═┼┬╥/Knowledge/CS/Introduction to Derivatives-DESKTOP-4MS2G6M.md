#归档/📦/derivatives

This class about DIFFERENTIATION

## WHAT IS A DERIVATIVE?

- ==[[Geometric interpretation]]==
- Physical interpretation

### Why Calculus is so Fundamental?

- Importance to all measurements
	(sience, eng, econormics, political science. etc)

## HOW TO DIFFERENTIATE ANY FUNCTION YOU KNOW?

Example:

	Take the derivative.

	![[Pasted image 20221213134205.png]]
