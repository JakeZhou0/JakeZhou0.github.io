## [[MIT18.01 Calculus]]

## [[MIT18.02 Calculus]]

## [[MIT18.06 Linear Algebra]]

## [[MIT6.050J Information theory and Entropy]]

[搭配视频学习数学]((<https://www.youtube.com/watch?v=WUvTyaaNkzM&list=PLZHQObOWTQDMsr9K-rj53DwVRMYO3t5Yr&index=1>)
