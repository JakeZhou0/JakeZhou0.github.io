In September 1947, operators on the Harvard Mark 2 pulled a dead moth form a malfunctioning relay.

[[Grace Hopper]] noted, "**From then on, when anything went wrong with a computer, we said it had bugs in it.**"
