## 基础

- [按键列表(键盘, 鼠标和操纵杆) | AutoHotkey v2 (wyagd001.github.io)](https://wyagd001.github.io/v2/docs/KeyList.htm)
- [热键 - 定义 & 使用 | AutoHotkey v2 (wyagd001.github.io)](https://wyagd001.github.io/v2/docs/Hotkeys.htm)
- [热字串](https://wyagd001.github.io/v2/docs/Hotstrings.htm)

## 参考

- [初学者向导 | AutoHotkey v2 (wyagd001.github.io)](https://wyagd001.github.io/v2/docs/Tutorial.htm#s12)
