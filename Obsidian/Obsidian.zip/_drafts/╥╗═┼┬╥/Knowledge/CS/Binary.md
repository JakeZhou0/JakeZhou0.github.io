## What is Binary?

Two states of electricity. We call this representation '[[Knowledge/CS/Binary]]', the binary can represent important information.
