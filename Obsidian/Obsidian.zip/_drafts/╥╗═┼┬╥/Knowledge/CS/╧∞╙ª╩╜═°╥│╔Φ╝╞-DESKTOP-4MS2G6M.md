我认为这个这些知识非常有用的，在之后的 Web 开发中，我可以更多的应用这项技术

使用技术：

- [HTML](HTML.md)
- [CSS](CSS.md)

## 目前主要需要学习的知识点有这些

- HTML5 new label
- Basic CSS
- Use CSS Typography
- Learn Accessibility
- CSS Pseudo Selectors
- SVG icons, CSS positioning
- Responsive Web Design
- CSS variables
- CSS Animation
- CSS Transforms
