Invented in [[Mesopotamia]] around 2500BCE.

It's a hand operated calculator, that helps add and subtract many numbers.

## Why Do People Need to Calculator?

The abacus was created because, the scale of society had become greater.

## Basic Abacus

![[Knowledge/CS/附件/Pasted image 20221208164746.png]]

Each row representing a different power of ten.(2:57)
