One of the largest [[electro-mechanical]] computers built was the [[Knowledge/CS/Harvard Mark 1]].

## [[Manhattan Project]]

### WHAT IS A MECHANICAL RELAY?

A control wire that determines whether a ciruit is opened or closed.

**Relay like a water faucet.** %%The control wire is like the faucet handle. open the faucet, and water flows through the pipe. Close the faucet, and the flow of water stops.%%

#### Mechanical Relay Defect

1. WEAR & TEAR.
2. NOT FAST ENOUGH.

#### [[Computer term]]

**[[Knowledge/CS/BUG]]**

## Alternative

[[Ambrose Fleming]] developed a [[thermionic valve]]

[[Lee de Forest]] added a third "control", Call [[triode vacuum tubes]]

The first large-scale use of vacuum tubes for computing was the [[Colossus Mk 1]]. **The helped to decrypt Nazi communications.**

The [[ENIAC]] completed in 1946 at the [[University of Pennsylvania]]. This was the **world's first truly general purpose, programmable, electronic** computer.

In 1947, [[Bell Laboratory]] scientists [[John Bardeen]], [[Walter Brattain]], and [[William Shockley]] invented the [[transistor]].

A lot of this transistor and [[semiconductor]] development happened in the [[Santa Clara Valley]].

## SUMMARY

**The ENIAC completed in 1946. This was the world's first truly general purpose, programmable, electronic computer.**
