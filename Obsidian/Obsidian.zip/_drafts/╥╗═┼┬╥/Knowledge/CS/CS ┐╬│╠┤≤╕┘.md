## [[Knowledge/CS/我需要学习哪些技能？]]

## 课程大纲

[【计算机科学速成课】[40集全/精校] - Crash Course Computer Science_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1EW411u7th/?spm_id_from=333.337.search-card.all.click&vd_source=259864d291ade3cf8d6e26d8a656dd53)

- ## [[Knowledge/CS/必学工具]]
- ## [[书籍推荐]]
- ## [[Knowledge/CS/数学基础]]
- ## [[数学进阶]]
- ## [[Knowledge/CS/编程入门]]
- ## [[电子基础]]
- ## [[数据结构与算法]]
- ## [[Knowledge/CS/软件工程]]
- ## [[体系结构]]
- ## [[操作系统]]
- ## [[ 并行与分布式系统]]
- ## [[Knowledge/CS/计算机系统安全]]
- ## [[Knowledge/附件/计算机网络]]
- ## [[数据库系统]]
- ## [[Knowledge/CS/编译原理]]
- ## [[计算机图形学]]
- ## [[Knowledge/CS/Web开发]]
- ## [[数据科学]]
- ## [[Knowledge/CS/人工智能]]
- ## [[Knowledge/CS/机器学习]]
- ## [[机器学习系统]]
- ## [[Knowledge/CS/深度学习]]
- ## [[机器学习进阶]]

[[Knowledge/CS/CS 领域问题]]
