---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/Java
  - 归档/📦/基础
  - 归档/📦/算法
  - 归档/📦/Codewars
---

## 🙋‍♀️Question

---

> [!Question] What does this topic mean?

> [!Question] How can I do this topic?

## 📝Note

---

### Topic

> That it squares each number passed in to it and then sums the results together.

### The Ways

- Use for loops.
- Calculate square each number and sum they.

### ❓Don't Understand

> [!Words]  
> square | passed

## 🔥Summary

---
- Easy topic.
