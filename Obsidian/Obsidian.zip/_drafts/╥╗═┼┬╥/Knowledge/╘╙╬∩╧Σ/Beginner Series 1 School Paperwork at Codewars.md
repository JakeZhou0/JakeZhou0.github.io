---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Codewars
  - 归档/📦/Java
  - 归档/📦/基础
  - 归档/📦/算法
---

## 🙋‍♀️Question

---

> [!Question] What does this topic talk about?

> [!Question] How to do this topic?

## 📝Note

---

### Topic

> Here has `n` classmates, and each person needs to copy `m` pages of paperwork.

This topic is easy. We can use an `if` statement to check if either `n` or `m` is greater than 0 then return `n` times `m` value.

### ❓Don't Understand

> [!Words]  
> paperwork | blank |

I don't know this topic mean.

## 🔥Summary

---
- We need to comprehend the topic's meaning.
