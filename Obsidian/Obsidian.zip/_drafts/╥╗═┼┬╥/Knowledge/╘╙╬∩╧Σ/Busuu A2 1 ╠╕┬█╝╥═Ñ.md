---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Busuu
  - 归档/📦/English
---

## Question

- 家庭的成员有哪些？
- 如何询问有哪些家人？
- 如何向一个人介绍我有哪些家人？

## Note

### 我知道的家庭的成员？

> Brother Sister Mom Dad Son Aunt Cousin

### 询问家人

> How many family are you have?  
> What does work your mom?  

### 如何向一个人介绍我有哪些家人？

> I have ……  

### 不明白的知识？

- 叔叔的英语单词这么写？
- 父母的英文单词如何写？
- 女儿这个词如何拼写？
- 规范的询问别人家人，

## Summary

- 单词用到再说吧，现在记记那么多也没有什么用处，记自己用的到的词就足够了，**记得多，不如记得精**
