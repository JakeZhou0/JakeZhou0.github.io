---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/VOA
---

## 🙋‍♀️Question

---

> [!Question] What happened after meeting Anna family?

> [!Question] What does this video teach?

## 📝Note

---

### Learn Family Ties

### What Happened This Video?

1. Anna thinking about family.
2. Anna's friend ask Anna what's wrong?
3. Anna shows her family's photo with her friend.

### ❓Don't Understand

> [!Words]  
> rodeo clowns | picture | lavender | spoons | farmer
> raise | sweaters | garden | homesick | joke | laugh |

## 🔥Summary

---
- About Anna's famliy.
