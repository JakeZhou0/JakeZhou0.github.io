---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/Java
  - 归档/📦/基础
  - 归档/📦/算法
---

## 🙋‍♀️Question

---

> [!Question] 1 What does this exercise practice mean?

> [!Question] 2 How to do this exercise practice?

> [!Question] 3 This exercise practice which fundamental concept in Java?

> [!Question] 4 How can I receive the return value of a stream?

## 📝Note

---

### Ways

1. To use Loops arrays find the smallest integer.
2. To use [[Java Stream]] find the smallest integer.

### ❓Don't Understand

> [!Words]  
> given | smallest integer | solution | assume | purpose | supplied | empty

> [!Java Fundamental]  
> - What is stream in Java?
> - Why do we need to use the stream in Java?
> - How to use stream in Java?
> - I use stream with compliss bigerd and smallest and I don't know how to receive a return value.

## 🔥Summary

---
- Find the smallest integer in the array.
- Two ways to do this practice exercise.
- Loop statement use and how to use Java Stream find min?
