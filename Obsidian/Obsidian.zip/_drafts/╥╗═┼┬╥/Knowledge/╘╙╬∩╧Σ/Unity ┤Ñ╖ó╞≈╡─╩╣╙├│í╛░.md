---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Unity
  - 归档/📦/Game
---

## 📝Note

---

### 测试触发器是否被触发

```C#
//测试
private void OnTriggerStay2D(Collider2D collision)
{
    Debug.Log(collision.name);
}
```

### 检测伤害

### ❓Don't Understand

## 🔥Summary

---
