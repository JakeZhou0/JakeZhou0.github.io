---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Busuu
  - 归档/📦/English
---

## 🙋‍♀️Question

---

> [!Question] 1 What kind of person is Nadiya?

> [!Question] 2 How many Nadiya's family for person?

## 📝Note

---

### Number of People

- Husband
- Children: 1boy and 2 daughter
- parents
- Three sisters
- Two brothers
- grandmother

### ❓Don't Understand

> [!word]  
> famous | grew up | won | competition | important part | chef | celebrations | meals  
> mutton | culture | picks | village | guests here | gonna cry | turns out | continues | travels

What does this mean?

- She `won` The Great British Bake Off, a TV `competition`.
- She `grew up` in the UK
- I feel very British

## 🔥Summary

---
- When Talk about our family, and we need talk about important family members.
