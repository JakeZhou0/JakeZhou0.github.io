---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/VOA
  - 归档/📦/English
---

## 🙋‍♀️Question

---

> [!Question] 1 What is it cold?

> [!Question] 2 Where is the Mexico City?

> [!Question] 3 How to talk about the weather?

## 📝Note

---

### **SEVEN** Weather Conditions

- **[[sunny]]**
- [[rainy]]
- **[[windy]]**
- [[foggy]]
- **[[snowy]]**
- [[stormy]]
- [[cloudy]]

### **FOUR** Main Temperatures

- hot
- **warm**
- **cold**
- cool

### Ask Weather

- What is today's temperature?
- Is it windy…?

### ❓Don't Understand

> [!Words]  
> forecast | temperature | Celsius | Fahrenheit | Snowy | Washington weather |

## 🔥Summary

---
**Today is cold and windy.**
