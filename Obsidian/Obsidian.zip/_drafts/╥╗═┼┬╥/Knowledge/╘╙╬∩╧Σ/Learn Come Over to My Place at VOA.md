---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/VOA
---

## 🙋‍♀️Question

---

> [!Question] 1 What does this topic mean?

> [!Question] 2 How to express that place?

## 📝Note

---

### Express that Place way

- turn right
- turn left
- exit the something
- straight ahead

### ❓Don't Understand

> [!Words]  
> come over | straight ahead | which | across from | department store

> [!Statement]  
> - I'm coming to your apartment.
> - Then walk **straight ahead**.
> - **which** coffee shop?
> - My apartment is **across from** a big **department store**.
> - I love having my friends over.

## 🔥Summary

---
- I want find the bus. Could you help me find near bus?
- Yes, Exit the university at east door, than turn right and you can see bus station.
