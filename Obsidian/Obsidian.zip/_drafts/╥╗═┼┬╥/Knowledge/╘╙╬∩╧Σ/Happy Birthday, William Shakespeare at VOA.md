---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - "#归档/📦/English"
  - 归档/📦/VOA
---

## 🙋‍♀️Question

---

> [!Question] What does William Shakespeare mean?

> [!Question] What does this topic say?

## 📝Note

---

### Connect

But today say like: Butoday.

### William Shakespeare

> William Shakespeare likes party. It may a person, like king.

### ❓Don't Understand

> [!Words]  
> exercise | garden | unusual | drum band | puppet shows | clothes | usual  
> politician | President | majesty | sword fighting | William Shakespeare  
> bored |

## 🔥Summary

---
- Butoday.
- I'm bored.
