---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
---

## 🙋‍♀️Question

---

> [!Question] What does that topic mean?

> [!Question] What do I need to learn?

## 📝Note

---

###


- What does your boss look like?

### ❓Don't Understand

## 🔥Summary

---
- describe people.
