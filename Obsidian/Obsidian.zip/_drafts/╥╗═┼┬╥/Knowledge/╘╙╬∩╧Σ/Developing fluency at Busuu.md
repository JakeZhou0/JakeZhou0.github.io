---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
---

## 🙋‍♀️Question

---

> [!Question] What does this topic?

> [!Question]

## 📝Note

---

### Learn Superlative

### ❓Don't Understand

**Superlative**
- superlative of "rude" is rudest.
- My son is more creative than my daughter. (My son is than more creative my daughter.)

## 🔥Summary

---

### Superlative

- someone is the -est than some people.
- someone is the most -est than some people.
