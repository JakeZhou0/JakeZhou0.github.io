---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Busuu
  - 归档/📦/English
---

## 🙋‍♀️Question

---

> [!Question] What is comparisons?

> [!Question] How to make comparisons?

## 📝Note

---

### What's Comparison?

This is ChatGPT aswen:

> "Comparison" is like when you look at two or more things to see what's the same and what's different. It's like when you check out two toys and decide which one you like better because of how they look or what they can do. So, it's basically just comparing, or seeing how things are alike or not alike.

### Making Comparisons

- more …… than ……
- less …… than ……
- fewer……than……

> [!Tip]
> `less` is used with uncountable nouns.
> `fewer` is used with countable nouns.
> `more` is used with both.

### ❓Don't Understand

> [!Words]
> prefers | continue |

- What does continue mean?

## 🔥Summary

---
- I learn more knowledge than my brother.
