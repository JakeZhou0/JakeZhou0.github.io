---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Java
  - 归档/📦/基础
  - 归档/📦/算法
  - 归档/📦/Codewars
---

## 🙋‍♀️Question

---

> [!Question] This a topic what does mean？

> [!Question] How do I write this program with summation.

> [!Question] What is positive integer?

## 📝Note

---

### The Meaning of the Title

- The summation of every number from 1 to num.
- The number will be a positive integer greater than 0(n > 0).

### So how Can I Write This Program?

use for.

### ❓Don't Understand

> [!note] Words
> - Summation
> - Positive integer
> - greater (like >)
> - reach

for

## 🔥Summary

---
- This topic can involve math functions, but I use simple methods, such as loops.
