---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Busuu
  - 归档/📦/English
---

## 🙋‍♀️Question

---

> [!Question] How can I to compare different people?

> [!Question]

## 📝Note

---

### ❓Don't Understand

> [!Words]  
> [[painting]] | [[organized]] | [[review]] | [[creative]] | [[finish]]

## 🔥Summary

---
