---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/Busuu
---

## 🙋‍♀️Question

---

> [!Question] How to describing someone's personality?

## 📝Note

---

### Personality

- **commendatory**
	- kind
	- friendly
	- polite
	- fun
	- funny
- **disparage**
	- shy
	- rude
	- lazy

### ❓Don't Understand

> [!Words]  
> kind | polite | guy | rude | bit | seem |

> [!Statement]  
> - My dad can **be** a bit lazy sometimes
> - You **seem** really kind.

## 🔥Summary

---
- You are very kind and polite.
