---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
---

## 🙋‍♀️Question

---

> [!Question]

> [!Question]

## 📝Note

---

### 1. 使用创建 C# 文件设置角色的基本属性（Character）

![[../../../附件/Pasted image 20240202014227.png]]

1. 设置角色基本属性

> [!Example]
> 最大的血量，当前血量等等

![[../../../附件/Pasted image 20240202014944.png]]

![[../../../附件/Pasted image 20240202015026.png]]

h

### ❓Don't Understand

## 🔥Summary

---
