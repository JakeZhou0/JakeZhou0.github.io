---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
---

## 🙋‍♀️Question

---

> [!Question] 如何总结笔记？为什么需要总结笔记？

> [!Question] 如何使用代码实现镜头跟随玩家？

> [!Question] 游戏中如何实现伤害计算？为什么需要伤害计算？

> [!Question] 触发器碰撞体的关系？他们分别的应用场景是什么？如何使用？

> [!Question] 使用设置为 Trigger 后，如何检测玩家是否触碰到这个触发器？

## 📝Note

---

### 使用 Unity 进行 [[伤害计算]]

### [[Unity 触发器的使用场景]]

###


## 🔥Summary

---
