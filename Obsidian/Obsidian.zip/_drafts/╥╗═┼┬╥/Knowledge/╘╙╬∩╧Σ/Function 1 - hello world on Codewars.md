---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/算法
  - 归档/📦/Java
  - 归档/📦/基础
---

## 🙋‍♀️Question

---

> [!Question] What does this topic mean?

> [!Question] How can I use function in Java?
j

## 📝Note

---

### Topic

- Make a function called `greet` that returns the "hello world!".

### ❓Don't Understand

## 🔥Summary

---
- Easy the topic.
