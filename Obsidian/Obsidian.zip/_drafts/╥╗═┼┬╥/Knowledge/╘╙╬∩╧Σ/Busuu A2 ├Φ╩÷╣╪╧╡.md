---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/Busuu
  - 归档/📦/English
  - 归档/📦/A2
---

## 🙋‍♀️Question

---

> [!Question] 1 How to express your relationship with someone?

> [!Question] 2 How can I convey that we have a good relationship?

> [!Question] 3 How can I convey that we have a bad relationship?

> [!Question] 4 How can I ask someone relationship?

## 📝Note

---

### Express the Relationship

- good relationship
	- get along well
	- get on well
	- be close someone

### Ask the Relationship

- How do you know each other?
- Do you get along well？
- How are you getting along?
- Do you have a good relationship with him?

### ❓Don't Understand

> [!Words]  
> fight | each other | one another |

## 🔥Summary

---
- My sister and I fight with along another often, I don't get along well with my sister. What are you get on well with you family?
