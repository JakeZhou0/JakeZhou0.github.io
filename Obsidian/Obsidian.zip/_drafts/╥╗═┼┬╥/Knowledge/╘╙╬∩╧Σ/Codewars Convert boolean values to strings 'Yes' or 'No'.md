---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/基础
  - 归档/📦/算法
  - 归档/📦/Java
  - 归档/📦/Codewars
---

## 🙋‍♀️Question

---

> [!Question] 1 What does this topic mean?

> [!Question] 2 How to do this topic?

## 📝Note

---

### The Topic Mean

- The method that takes a boolean value and return a `"Yes"` string for `true` , or a `"No"` string for `false`.

### How to Do

1. Use **if statement**.

### ❓Don't Understand

> [!Words]  
> [[convert]] | if statement

## 🔥Summary

---
- Use **if statement**
