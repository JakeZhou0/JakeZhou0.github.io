---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/Busuu
---

## 🙋‍♀️Question

---

> [!Question] How to describe personality?

> [!Question] What kind of personality traits do people possess?

## 📝Note

---

### This is Extent Article

- [[Busuu A2 describe different personality]]

### Personality

- good habit
	- tidy
	- organized
	- creative
	- to be good at something
	- helpful
- bad habit
	- disorganized
	- untidy

### ❓Don't Understand

> [!Words]  
> organized | being able | loses | paints | pictures | talents | willing |

	I don't know what is organized, What's the difference between organized and organised?

## 🔥Summary

---
- You are kind, do you know?
- I think I'm good at computer.
