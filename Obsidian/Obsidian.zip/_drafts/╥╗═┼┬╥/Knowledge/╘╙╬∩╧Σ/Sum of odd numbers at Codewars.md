---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/算法
  - 归档/📦/Java
  - 归档/📦/Codewars
  - 归档/📦/基础
---

## 🙋‍♀️Question

---

> [!Question] What does this topic mean?

> [!Question] How can I solve this preblem?

> [!Question] How can I solve this preblem?

## 📝Note

---

### Topic

To calculate number's three power then return value.

### ❓Don't Understand

> [!Words]  
> odd | triangle | consecutive | $n^{th}$ |

How to calculate a number's power?

## 🔥Summary

---
- Using English understanding the topic is important.
- Math.pow();
