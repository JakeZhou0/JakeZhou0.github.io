---
tags:
  - 归档/📦/笔记
  - 归档/📦/Learn
  - 归档/📦/Study
  - 归档/📦/English
  - 归档/📦/VOA
---

## 🙋‍♀️Question

---

> [!Question] What does Neighborhood mean?

> [!Question] What is taught in this lesson?

## 📝Note

---

### Topics

- describing neighborhoods.
- Asking for information.
- Ask place.
- Answer place.

### Grammar

Prepositions (across from).

### ❓Don't Understand

> [!Words]  
> neighborhood | errands | corner | awesome | across | stamp | cash

- How to use preposition?
- What is stamp?

> [!Statement]
> - **DC** is a city for walking.
> - In our neighborhood, I can do all my errands.
> - back home.

## 🔥Summary

---
- The stores composition neighborhood.
