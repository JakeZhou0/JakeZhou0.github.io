## 预选

* [ChatGPT3.5](https://chat.openai.com/)
* [Google 表格](https://docs.google.com/spreadsheets/u/0/)
* [Excel | Microsoft 365 (office.com)](https://www.office.com/launch/excel?ui=zh-CN&rs=CN&auth=1)
* [Cursor | Build Fast](https://www.cursor.so/)
* [免費即時變聲器 - Voicemod](https://www.voicemod.net/zh/)
* [Cleanup.pictures - Remove objects, people, text and defects from any picture for free](https://cleanup.pictures/)
* [CapCut | All-in-one video editor](https://www.capcut.com/)
* [Luminar AI - Edit your Photos With Automatic Modes Supported By AI (skylum.com)](https://skylum.com/hans/luminar-ai)
* [来自 Microsoft 必应的图像创建者 (bing.com)](https://www.bing.com/create?via=aitoolsarena.com)
