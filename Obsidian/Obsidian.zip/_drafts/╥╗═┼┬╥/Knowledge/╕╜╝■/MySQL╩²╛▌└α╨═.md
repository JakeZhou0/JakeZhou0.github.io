## 数值类型

![[Knowledge/素材/Pasted image 20230312003339.png]]

## 字符串类型

![[Knowledge/素材/Pasted image 20230312003444.png]]

## 日期时间类型

![[Knowledge/素材/Pasted image 20230312003524.png]]
