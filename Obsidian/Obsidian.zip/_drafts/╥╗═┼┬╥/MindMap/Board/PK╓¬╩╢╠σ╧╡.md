---
excalidraw-plugin: parsed
tags: [归档/📦/excalidraw]
---

==⚠ Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==

## Text Elements

归档 ^rssziOdQ

资源 ^KRD3dqN3

[[搭建知识系统]] ^qUi9QFYw

项目 ^7HQTXoOj

[[搭建标签系统]] ^GJpgeMuy

领域 ^0rEKD6ZZ

[[Media Note - 组织信息的Obsidian实践，建立专业博学的知识地图]] ^496m6Etg

[[P.A.R.A]] ^1R36Ntmz

[[个人知识管理系统]] ^5HE3t53r

%%

## Drawing

```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.1.4",
	"elements": [
		{
			"type": "ellipse",
			"version": 100,
			"versionNonce": 545503784,
			"isDeleted": false,
			"id": "avz7LjCoQIo-hivoHQbmL",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 80.55713853449276,
			"y": -11.304894527755835,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 296.6476114277781,
			"height": 185.67133834035286,
			"seed": 1488647256,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1713314874837,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 601,
			"versionNonce": 279469912,
			"isDeleted": false,
			"id": "v9zpZKQ360DTSKf_VQGu0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 38.10306133475564,
			"y": -1133.1345848020883,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 649.2407857551551,
			"height": 649.2407857551551,
			"seed": 993282813,
			"groupIds": [
				"1gwhgtA8W4zENFe2u_WH-"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "wU9ohZ-m8NGCLcuM08W8K",
					"type": "arrow"
				}
			],
			"updated": 1713315037254,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 816,
			"versionNonce": 536445528,
			"isDeleted": false,
			"id": "CZBCSAIrs-DZtJIiG3TnI",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1191.1582515155806,
			"y": -664.3242371828135,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 895.5705382081333,
			"height": 895.5705382081333,
			"seed": 1556606419,
			"groupIds": [
				"F5JRTQxA5GuvNe7rPWert"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "d0kUTHR7lSX8lViml519W",
					"type": "arrow"
				},
				{
					"id": "mXkG_VTyTFYR0OR1x_8k0",
					"type": "arrow"
				}
			],
			"updated": 1713314484044,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 933,
			"versionNonce": 404254504,
			"isDeleted": false,
			"id": "rssziOdQ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1517.2069848545068,
			"y": -600.8805816114902,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 106.37997436523438,
			"height": 132.97623922498082,
			"seed": 802208627,
			"groupIds": [
				"F5JRTQxA5GuvNe7rPWert"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314484044,
			"link": null,
			"locked": false,
			"fontSize": 53.19049568999233,
			"fontFamily": 1,
			"text": "\n归档",
			"rawText": "\n归档",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "\n归档",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 128,
			"versionNonce": 1610841688,
			"isDeleted": false,
			"id": "0rEKD6ZZ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 289.60739878092096,
			"y": -1050.0081507466048,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 117.55999755859375,
			"height": 70.54647261462523,
			"seed": 1025368366,
			"groupIds": [
				"1gwhgtA8W4zENFe2u_WH-"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713315037254,
			"link": null,
			"locked": false,
			"fontSize": 58.78872717885436,
			"fontFamily": 3,
			"text": "领域",
			"rawText": "领域",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "领域",
			"lineHeight": 1.2
		},
		{
			"type": "rectangle",
			"version": 445,
			"versionNonce": 747653672,
			"isDeleted": false,
			"id": "QyQSWQIEt2ZYPwPyNbNzV",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 69.6517954003678,
			"y": -164.34779286799042,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 496.4100800430395,
			"height": 398.31523756404954,
			"seed": 560355517,
			"groupIds": [
				"OcFxfuBS3BwFC7nc5EDI_"
			],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "wU9ohZ-m8NGCLcuM08W8K",
					"type": "arrow"
				},
				{
					"id": "d0kUTHR7lSX8lViml519W",
					"type": "arrow"
				},
				{
					"id": "1YrdbMoRynKYxQYVTbQaN",
					"type": "arrow"
				},
				{
					"id": "mXkG_VTyTFYR0OR1x_8k0",
					"type": "arrow"
				}
			],
			"updated": 1713314484044,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 233,
			"versionNonce": 995411240,
			"isDeleted": false,
			"id": "7HQTXoOj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 211.66185288395997,
			"y": -141.74449438188313,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 167.03997802734375,
			"height": 104.40674855852195,
			"seed": 304453705,
			"groupIds": [
				"OcFxfuBS3BwFC7nc5EDI_"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314484044,
			"link": null,
			"locked": false,
			"fontSize": 83.52539884681757,
			"fontFamily": 1,
			"text": "项目",
			"rawText": "项目",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "项目",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 320,
			"versionNonce": 879257640,
			"isDeleted": false,
			"id": "GJpgeMuy",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 119.93262803700082,
			"y": 70.70729110213301,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 53.02491760253906,
			"height": 7.549813922917829,
			"seed": 1612821287,
			"groupIds": [
				"OcFxfuBS3BwFC7nc5EDI_"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314550886,
			"link": "[[搭建标签系统]]",
			"locked": false,
			"fontSize": 6.039851138334263,
			"fontFamily": 1,
			"text": "📍[[搭建标签系统]]",
			"rawText": "[[搭建标签系统]]",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "📍[[搭建标签系统]]",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 605,
			"versionNonce": 242819880,
			"isDeleted": false,
			"id": "qUi9QFYw",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 149.5681373267482,
			"y": 26.41346426685061,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 164.8785400390625,
			"height": 23.440001109215984,
			"seed": 598831795,
			"groupIds": [
				"OcFxfuBS3BwFC7nc5EDI_"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314550886,
			"link": "[[搭建知识系统]]",
			"locked": false,
			"fontSize": 18.752000887372787,
			"fontFamily": 1,
			"text": "📍[[搭建知识系统]]",
			"rawText": "[[搭建知识系统]]",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "📍[[搭建知识系统]]",
			"lineHeight": 1.25
		},
		{
			"type": "arrow",
			"version": 317,
			"versionNonce": 157968728,
			"isDeleted": false,
			"id": "wU9ohZ-m8NGCLcuM08W8K",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 249.5934950904795,
			"y": -174.47043495032284,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 106.04035649946383,
			"height": 285.4906197025859,
			"seed": 425225560,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1713315037254,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QyQSWQIEt2ZYPwPyNbNzV",
				"gap": 10.122642082332447,
				"focus": -0.451262548859752
			},
			"endBinding": {
				"elementId": "v9zpZKQ360DTSKf_VQGu0",
				"gap": 24.004838520294044,
				"focus": -0.35338670547406165
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					106.04035649946383,
					-285.4906197025859
				]
			]
		},
		{
			"type": "arrow",
			"version": 189,
			"versionNonce": 1862601560,
			"isDeleted": false,
			"id": "d0kUTHR7lSX8lViml519W",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1373.9804430356985,
			"y": -591.5925211532701,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 6.117392091873853,
			"height": 6.373201383308526,
			"seed": 2087435304,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1713314484044,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "CZBCSAIrs-DZtJIiG3TnI",
				"focus": -0.15311545084111108,
				"gap": 11.421220567608032
			},
			"endBinding": {
				"elementId": "CZBCSAIrs-DZtJIiG3TnI",
				"gap": 2.6881381255054464,
				"focus": 0.15311545084109912
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					6.117392091873853,
					6.373201383308526
				]
			]
		},
		{
			"type": "arrow",
			"version": 756,
			"versionNonce": 671204696,
			"isDeleted": false,
			"id": "1YrdbMoRynKYxQYVTbQaN",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 46.015950554651425,
			"y": 78.77605689533448,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 575.753959114204,
			"height": 215.68236163693348,
			"seed": 1259230040,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1713314966829,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QyQSWQIEt2ZYPwPyNbNzV",
				"gap": 23.63584484571635,
				"focus": 0.1980268400818874
			},
			"endBinding": {
				"elementId": "RYy3LlL2TbWuC8UvRFgu2",
				"gap": 9.070910565566692,
				"focus": 0.20852989252989923
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-575.753959114204,
					215.68236163693348
				]
			]
		},
		{
			"type": "arrow",
			"version": 271,
			"versionNonce": 1039786072,
			"isDeleted": false,
			"id": "mXkG_VTyTFYR0OR1x_8k0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 573.9516109781329,
			"y": 11.197090547523032,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 614.0007270048142,
			"height": 153.13908744943376,
			"seed": 48517672,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1713314484044,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QyQSWQIEt2ZYPwPyNbNzV",
				"gap": 7.889735534725446,
				"focus": 0.1539884085414726
			},
			"endBinding": {
				"elementId": "CZBCSAIrs-DZtJIiG3TnI",
				"gap": 9.333703292406085,
				"focus": 0.08209182078573499
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					614.0007270048142,
					-153.13908744943376
				]
			]
		},
		{
			"type": "ellipse",
			"version": 790,
			"versionNonce": 2093586984,
			"isDeleted": false,
			"id": "RYy3LlL2TbWuC8UvRFgu2",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1177.5574518905787,
			"y": -56.876769652935536,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 640.2378527811087,
			"height": 778.3493055646582,
			"seed": 643626589,
			"groupIds": [
				"Mba8y_pZNNsUHzlSDY4Iw",
				"7IESOUnYE102ghdyC6juv"
			],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "1YrdbMoRynKYxQYVTbQaN",
					"type": "arrow"
				}
			],
			"updated": 1713314966812,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 834,
			"versionNonce": 336453720,
			"isDeleted": false,
			"id": "KRD3dqN3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -899.4052233406301,
			"y": 16.66443886118384,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 122.63998413085938,
			"height": 76.65547887990907,
			"seed": 1871192765,
			"groupIds": [
				"Mba8y_pZNNsUHzlSDY4Iw",
				"7IESOUnYE102ghdyC6juv"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314977253,
			"link": null,
			"locked": false,
			"fontSize": 61.324383103927254,
			"fontFamily": 1,
			"text": "资源",
			"rawText": "资源",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "资源",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 350,
			"versionNonce": 216984360,
			"isDeleted": false,
			"id": "496m6Etg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1107.8665690735056,
			"y": 130.71568078123482,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 472.4458923339844,
			"height": 16.45801632380777,
			"seed": 40331,
			"groupIds": [
				"7IESOUnYE102ghdyC6juv"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314966812,
			"link": "[[Media Note - 组织信息的Obsidian实践，建立专业博学的知识地图]]",
			"locked": false,
			"fontSize": 13.715013603173142,
			"fontFamily": 3,
			"text": "📍[[Media Note - 组织信息的Obsidian实践，建立专业博学的知识地图]]",
			"rawText": "[[Media Note - 组织信息的Obsidian实践，建立专业博学的知识地图]]",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "📍[[Media Note - 组织信息的Obsidian实践，建立专业博学的知识地图]]",
			"lineHeight": 1.2
		},
		{
			"type": "text",
			"version": 239,
			"versionNonce": 774290264,
			"isDeleted": false,
			"id": "1R36Ntmz",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1108.8326471111025,
			"y": 169.45577024343027,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 99.4912109375,
			"height": 16.45801632380777,
			"seed": 1359699288,
			"groupIds": [
				"Mba8y_pZNNsUHzlSDY4Iw",
				"7IESOUnYE102ghdyC6juv"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713314966812,
			"link": "[[P.A.R.A]]",
			"locked": false,
			"fontSize": 13.715013603173142,
			"fontFamily": 3,
			"text": "📍[[P.A.R.A]]",
			"rawText": "[[P.A.R.A]]",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "📍[[P.A.R.A]]",
			"lineHeight": 1.2
		},
		{
			"type": "text",
			"version": 132,
			"versionNonce": 16914520,
			"isDeleted": false,
			"id": "5HE3t53r",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 99.49195732691445,
			"y": -941.7205377063092,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ffffff",
			"width": 390.88067626953125,
			"height": 42.05714285714289,
			"seed": 1669117272,
			"groupIds": [
				"1gwhgtA8W4zENFe2u_WH-"
			],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1713315039462,
			"link": "[[个人知识管理系统]]",
			"locked": false,
			"fontSize": 35.04761904761908,
			"fontFamily": 3,
			"text": "📍[[个人知识管理系统]]",
			"rawText": "[[个人知识管理系统]]",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "📍[[个人知识管理系统]]",
			"lineHeight": 1.2
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "#ffffff",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 3,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": -111.42972782260665,
		"scrollY": 32.644257016093604,
		"zoom": {
			"value": 2.7625321459107544
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```

%%
