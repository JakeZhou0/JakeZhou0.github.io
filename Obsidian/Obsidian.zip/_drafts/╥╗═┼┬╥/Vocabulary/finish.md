---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> To finish something is to complete it or bring it to a conclusion. If you finished a race, you completed it -- even if you didn't come in first.

## 💭Imagine

---

![[../../附件/Pasted image 20231226193041.png]]

![[../../附件/Pasted image 20231226193046.png]]
