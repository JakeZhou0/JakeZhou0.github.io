---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> Painting is a visual composition on a cloth or canvas surface.

## 💭Imagine

---

![[../../附件/Pasted image 20231226114204.png]]

![Painting](https://cdn.busuu.com/media-resources/image/a/pr:exercise_l/plain/s3://busuu-logos-service-media-production/media-resources/image/a0a45ede-2153-4f05-b0f2-387cdfb272a4.jpg@jpg)
