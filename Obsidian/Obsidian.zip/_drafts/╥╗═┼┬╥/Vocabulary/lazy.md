---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> When we say someone is "lazy", we mean that they don't like to do things that require effort or work.

> [!Example]
> You have friend who has a lot of toys scattered around their room, and instead of picking them up, they just leave them on the floor. You might say, "My friend is being lazy because they don't want to clean up their toys."

## 💭Imagine

---

![[../../附件/Pasted image 20231229154150.png]]

![[../../附件/Pasted image 20231229154207.png]]
