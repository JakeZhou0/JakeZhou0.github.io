---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> A review is an evaluation or assessment of something, usually a product, service, of performance.

## 💭Imagine

---

![[../../附件/Pasted image 20231226123538.png]]
