---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

Looking at things to see how they are similar or different.

## 💭Imagine

---

### Imagine Words

comparative [[adjectives]], comparative & [[Superlatives at Busuu]].

![[../../附件/Pasted image 20231229144902.png]]

![[../../附件/Pasted image 20231229145113.png]]
