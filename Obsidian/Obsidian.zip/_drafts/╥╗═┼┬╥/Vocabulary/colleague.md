---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> A person you work with, especially someone who is a friend or someone you spend time with at you job or school.
> Like a friend or a person you work or study with.

## 💭Imagine

---

![[../../附件/Pasted image 20231229151411.png]]
