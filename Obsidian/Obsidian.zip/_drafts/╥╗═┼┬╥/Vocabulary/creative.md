---
tags:
  - 归档/📦/Vocabulary
  - 归档/📦/English
---

## Meaning

---

> - It is a term that can be used to describe a person, an idea, or a product.
>
> The ability to come up with new and original ideas or concepts.

## 💭Imagine

---

![[../../附件/Pasted image 20231226131950.png]]

![[../../附件/Pasted image 20231226132134.png]]

![[../../附件/Pasted image 20231226132155.png]]

![[../../附件/Pasted image 20231226132821.png]]

![[../../附件/Pasted image 20231226132228.png]]
