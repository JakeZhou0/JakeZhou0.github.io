---
model: ""
max_tokens: .nan
temperature: 1
reference_current_note: false
prompt: ""
user_name: USER
allow_header: true
chatbot_container_background_color: --background-secondary
message_container_background_color: --background-secondary
user_message_font_color: --text-normal
user_message_background_color: --background-primary
bot_message_font_color: --text-normal
chatbot_message_background_color: --background-secondary
chatbox_font_color: --text-normal
chatbox_background_color: --interactive-accent
prompt_select_generate_system_role: Output user request.
ollama_mirostat: 0
ollama_mirostat_eta: 0.1
ollama_mirostat_tau: 5
ollama_num_ctx: 2048
ollama_num_gqa: .nan
ollama_num_thread: .nan
ollama_repeat_last_n: 64
ollama_repeat_penalty: 1.1
ollama_seed: .nan
ollama_stop: []
ollama_tfs_z: 1
ollama_top_k: 40
ollama_top_p: 0.9
ollama_keep_alive: ""
---

You are a helpful assistant.
